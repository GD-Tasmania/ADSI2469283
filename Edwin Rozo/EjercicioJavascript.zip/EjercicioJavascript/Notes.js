// const body = document.getElementById("body")
const note1 = document.getElementById("number1")
const note2 = document.getElementById("number2")
const note3 = document.getElementById("number3")
const button = document.getElementById("button")
const result = document.getElementById("result")
const winner = document.getElementById("winner")
const recover = document.getElementById("recover")
const loser = document.getElementById("loser")
const honors = document.getElementById("honors")

button.addEventListener("click",exercise)

function exercise(){
    let not1 = Number(note1.value)
    let not2 = Number(note2.value)
    let not3 = Number(note3.value)
    let definitive = (not1*0.3)+(not2*0.3)+(not3*0.4)

    result.textContent="Su nota es: "+definitive.toFixed(2)
}
note2.addEventListener("keyup", function (event) {
    console.log("entra");
    let not1 = Number(note1.value)
    let not2 = Number(note2.value)
    let definitive = (not1*0.3)+(not2*0.3)
    if((definitive+(5*0.4)) > 2){
        winner.textContent="Para ganar la materia necesita minimo: "+((3.5-definitive)/0.4).toFixed(2)
        recover.textContent="Para ir a recuperacion necesita: "+((2.1-definitive)/0.4).toFixed(2)
        honors.textContent="Para aprobar con honores necesita: "+((4.6-definitive)/0.4).toFixed(2)
    }else{
        loser.textContent="Ya perdio la materia"
    }
});

// if(definitive<=2){
//     "Perdio la materia"
// } else if(definitive>=2.1 && definitive<=3.4){
//     "Tiene oportunidad de recuperar"
// } else if(definitive>=3.5 && definitive<=4.5){
//     "Ha aprobado de manera satisfactoria"
// } else if(definitive>=4.6 && definitive<=5){
//     "Ha aprobado y sera reconocido con honores"
// } else{
//     "Nota rara"
// }